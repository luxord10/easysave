﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EasySave.Model
{
    class Extension
    {
        public static string crypt { get; set; } = "";
        public static string prio { get; set; } = "";
    }
}
