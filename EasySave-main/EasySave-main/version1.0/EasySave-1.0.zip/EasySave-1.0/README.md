This is the first version of the save application. 
This is a console application that can only create a complete save. 
To fully appreciate the application, you have to use the console in full screen.
You have to enter the preliminary informations such as the folder you want to copy, the folder where you want to copy the files and the name of the save.
Then to save the files you just have to enter the name of the wanted save in the option "Save a Work" of the start menu.
