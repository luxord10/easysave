# EasySave
This is a Save Application created for a school project at CESI Ingineering School
This is the version 2.0 of our program. We add a Graphic User Interface in order to make the application easier to navigate and to use. You have to create a save work in the
"New Work" window. Here you have to enter the folder you want the copy, where you want it to be paste and a name to describe the save. Then to save the document of your folder, 
you have to enter the name of the save in the "Load Work" window.
Be careful, the app only does complete save. So if you want to update a save, you have to watch if there were files you want to keep in your target folder because they could be 
overwritten.
